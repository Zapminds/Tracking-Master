document.getElementById('searchButton').addEventListener('click', function() {
  const query = document.getElementById('searchQuery').value;
  if (query) {
    const trackingUrl = `https://trackingmaster.in/?s=${encodeURIComponent(query)}`;
    // Open the search in a new tab
    browser.tabs.create({ url: trackingUrl });
  } else {
    alert('Please enter your parcel company');
  }
});
